export function loadData() {
    return [
        { id: 1, name: "John Doe", age: 18, grade: "A" },
        { id: 2, name: "Jane Smith", age: 19, grade: "B" },
    ];
}
