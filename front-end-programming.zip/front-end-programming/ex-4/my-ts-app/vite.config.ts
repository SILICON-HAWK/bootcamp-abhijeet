// vite.config.js
export default {
    // config options
}